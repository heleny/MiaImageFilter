//
//  MiaImageFilter.h
//  MiaImageFilter
//
//  Created by admin on 8/2/17.
//  Copyright © 2017 hello from the other side. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MiaImageFilter : NSObject

@property (nonatomic,readonly) UIImage *originalImage;

- (id)initWithImage:(UIImage *)image;
- (UIImage *)grayScaleImage;
- (UIImage *)oldImageWithIntensity:(CGFloat)level;

@end
